// server.js
const path = require('path');
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// --- CONFIGURAÇÃO DE ARQUIVOS ESTÁTICOS ---
// Define a pasta "frontend" como pública para o servidor
app.use(express.static(path.join(__dirname, 'frontend')));

// Rota raiz: Envia o index.html (Tela de Login)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// --- BANCO DE DADOS ---
const db = new sqlite3.Database('./saep_db.db', (err) => {
    if (err) console.error('Erro ao conectar:', err);
    else {
        console.log('Conectado ao banco saep_db');
        initDb();
    }
});

function initDb() {
    db.serialize(() => {
        // 1. Tabela Usuários
        db.run(`CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            email TEXT UNIQUE,
            senha TEXT
        )`);

        // 2. Tabela Produtos
        db.run(`CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            preco REAL,
            quantidade INTEGER,
            quantidade_minima INTEGER
        )`);

        // 3. Tabela Movimentações (Histórico)
        db.run(`CREATE TABLE IF NOT EXISTS movimentacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER,
            usuario_id INTEGER,
            tipo TEXT, -- 'entrada' ou 'saida'
            quantidade INTEGER,
            data_movimentacao TEXT,
            FOREIGN KEY(produto_id) REFERENCES produtos(id),
            FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
        )`);

        // População Inicial (Seed)
        db.get("SELECT count(*) as qtd FROM usuarios", (err, row) => {
            if (row.qtd === 0) {
                console.log("Criando dados iniciais...");
                db.run(`INSERT INTO usuarios (nome, email, senha) VALUES 
                    ('Admin', 'admin@senai.br', '1234'),
                    ('João Silva', 'joao@teste.com', '1234')`);
                
                db.run(`INSERT INTO produtos (nome, preco, quantidade, quantidade_minima) VALUES 
                    ('Teclado Mecânico', 150.00, 20, 5),
                    ('Mouse Gamer', 80.00, 15, 5),
                    ('Monitor 24pol', 800.00, 8, 2)`);
            }
        });
    });
}

// --- ROTAS DA API ---

// 1. LOGIN
app.post('/api/login', (req, res) => {
    const { email, senha } = req.body;
    db.get('SELECT * FROM usuarios WHERE email = ? AND senha = ?', [email, senha], (err, row) => {
        if (row) res.json({ success: true, user: row });
        else res.status(401).json({ success: false, message: 'Credenciais inválidas' });
    });
});

// 2. PRODUTOS - Listar
app.get('/api/produtos', (req, res) => {
    const busca = req.query.busca;
    let sql = 'SELECT * FROM produtos';
    let params = [];

    if (busca) {
        sql += ' WHERE nome LIKE ?';
        params.push(`%${busca}%`);
    }
    
    if (req.query.ordenar === 'alfabetica') {
        sql += ' ORDER BY nome ASC';
    }

    db.all(sql, params, (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

// 3. PRODUTOS - Criar
app.post('/api/produtos', (req, res) => {
    const { nome, preco, quantidade, quantidade_minima } = req.body;
    if (!nome || !preco) return res.status(400).json({ error: 'Dados inválidos' });
    
    db.run('INSERT INTO produtos (nome, preco, quantidade, quantidade_minima) VALUES (?,?,?,?)', 
        [nome, preco, quantidade, quantidade_minima], function(err) {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ id: this.lastID });
    });
});

// 4. PRODUTOS - Editar
app.put('/api/produtos/:id', (req, res) => {
    const { nome, preco, quantidade, quantidade_minima } = req.body;
    db.run('UPDATE produtos SET nome=?, preco=?, quantidade=?, quantidade_minima=? WHERE id=?', 
        [nome, preco, quantidade, quantidade_minima, req.params.id], (err) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ message: 'Atualizado' });
    });
});

// 5. PRODUTOS - Excluir
app.delete('/api/produtos/:id', (req, res) => {
    db.run('DELETE FROM produtos WHERE id = ?', [req.params.id], (err) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ message: 'Excluído' });
    });
});

// 6. ESTOQUE - Registrar Movimentação (Com Alerta)
app.post('/api/movimentacao', (req, res) => {
    const { produto_id, usuario_id, tipo, quantidade, data } = req.body;
    
    db.get('SELECT * FROM produtos WHERE id = ?', [produto_id], (err, produto) => {
        if (err || !produto) return res.status(404).json({ error: 'Produto não encontrado' });

        let novaQtd = produto.quantidade;
        let alerta = null;

        if (tipo === 'entrada') {
            novaQtd += parseInt(quantidade);
        } else if (tipo === 'saida') {
            novaQtd -= parseInt(quantidade);
            if (novaQtd < 0) return res.status(400).json({ error: 'Estoque insuficiente' });
            
            // Lógica do Alerta de Estoque Mínimo
            if (novaQtd < produto.quantidade_minima) {
                alerta = `URGENTE: Estoque de "${produto.nome}" caiu para ${novaQtd} (Mínimo: ${produto.quantidade_minima})!`;
            }
        }

        // Atualiza quantidade
        db.run('UPDATE produtos SET quantidade = ? WHERE id = ?', [novaQtd, produto_id], (err) => {
            if (err) return res.status(500).json({ error: err.message });

            // Grava histórico
            db.run('INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, data_movimentacao) VALUES (?,?,?,?,?)',
                [produto_id, usuario_id, tipo, quantidade, data], (err) => {
                    if (err) return res.status(500).json({ error: err.message });
                    
                    res.json({ 
                        success: true, 
                        nova_quantidade: novaQtd, 
                        alerta_estoque: alerta 
                    });
            });
        });
    });
});

// 7. ESTOQUE - Listar Histórico (NOVO - Para a tabela de rastreabilidade)
app.get('/api/movimentacoes', (req, res) => {
    const sql = `
        SELECT m.*, p.nome as produto_nome, u.nome as usuario_nome 
        FROM movimentacoes m
        JOIN produtos p ON m.produto_id = p.id
        JOIN usuarios u ON m.usuario_id = u.id
        ORDER BY m.id DESC LIMIT 10
    `;
    db.all(sql, [], (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});