// server.js
const path = require('path'); // Necessário para encontrar a pasta frontend
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// --- CORREÇÃO AQUI ---
// Configura o servidor para procurar arquivos na pasta "frontend"
app.use(express.static(path.join(__dirname, 'frontend')));

// Força o envio do index.html quando acessar a raiz (http://localhost:3000)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});
// ---------------------

// 1. Conexão com Banco de Dados (Requisito: nome "saep_db")
const db = new sqlite3.Database('./saep_db.db', (err) => {
    if (err) console.error(err);
    else {
        console.log('Conectado ao banco saep_db');
        initDb();
    }
});

// 2. Criação das Tabelas e População Inicial (Requisitos 3.2 e 3.3)
function initDb() {
    db.serialize(() => {
        // Tabela Usuários
        db.run(`CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            email TEXT UNIQUE,
            senha TEXT
        )`);

        // Tabela Produtos
        db.run(`CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            preco REAL,
            quantidade INTEGER,
            quantidade_minima INTEGER
        )`);

        // Tabela Movimentações (Histórico)
        db.run(`CREATE TABLE IF NOT EXISTS movimentacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER,
            usuario_id INTEGER,
            tipo TEXT, -- 'entrada' ou 'saida'
            quantidade INTEGER,
            data_movimentacao TEXT,
            FOREIGN KEY(produto_id) REFERENCES produtos(id),
            FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
        )`);

        // População inicial (Se vazio) - Garante 3 registros por tabela
        db.get("SELECT count(*) as qtd FROM usuarios", (err, row) => {
            if (row.qtd === 0) {
                console.log("Populando banco de dados...");
                db.run(`INSERT INTO usuarios (nome, email, senha) VALUES 
                    ('Admin', 'admin@senai.br', '1234'),
                    ('João Silva', 'joao@teste.com', '1234'),
                    ('Maria Souza', 'maria@teste.com', '1234')`);
                
                db.run(`INSERT INTO produtos (nome, preco, quantidade, quantidade_minima) VALUES 
                    ('Teclado USB', 50.00, 100, 10),
                    ('Mouse Óptico', 25.00, 50, 5),
                    ('Monitor 24pol', 800.00, 15, 2)`);
            }
        });
    });
}

// --- ROTAS DA API ---

// Rota de Login (Requisito 4)
app.post('/api/login', (req, res) => {
    const { email, senha } = req.body;
    db.get('SELECT * FROM usuarios WHERE email = ? AND senha = ?', [email, senha], (err, row) => {
        if (row) {
            res.json({ success: true, user: row });
        } else {
            res.status(401).json({ success: false, message: 'Credenciais inválidas' });
        }
    });
});

// CRUD Produtos - Listar e Buscar (Requisito 6.1.1 e 6.1.2)
app.get('/api/produtos', (req, res) => {
    const busca = req.query.busca;
    let sql = 'SELECT * FROM produtos';
    let params = [];

    if (busca) {
        sql += ' WHERE nome LIKE ?';
        params.push(`%${busca}%`);
    }
    
    // Para a tela de Estoque, pede ordem alfabética (Requisito 7.1.1)
    if (req.query.ordenar === 'alfabetica') {
        sql += ' ORDER BY nome ASC';
    }

    db.all(sql, params, (err, rows) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(rows);
    });
});

// CRUD Produtos - Inserir (Requisito 6.1.3)
app.post('/api/produtos', (req, res) => {
    const { nome, preco, quantidade, quantidade_minima } = req.body;
    // Validação simples (Requisito 6.1.6)
    if (!nome || !preco) {
        return res.status(400).json({ error: 'Dados inválidos' });
    }
    db.run('INSERT INTO produtos (nome, preco, quantidade, quantidade_minima) VALUES (?,?,?,?)', 
        [nome, preco, quantidade, quantidade_minima], function(err) {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ id: this.lastID });
    });
});

// CRUD Produtos - Atualizar (Requisito 6.1.4)
app.put('/api/produtos/:id', (req, res) => {
    const { nome, preco, quantidade, quantidade_minima } = req.body;
    db.run('UPDATE produtos SET nome=?, preco=?, quantidade=?, quantidade_minima=? WHERE id=?', 
        [nome, preco, quantidade, quantidade_minima, req.params.id], (err) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ message: 'Atualizado' });
    });
});

// CRUD Produtos - Excluir (Requisito 6.1.5)
app.delete('/api/produtos/:id', (req, res) => {
    db.run('DELETE FROM produtos WHERE id = ?', [req.params.id], (err) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json({ message: 'Excluído' });
    });
});

// Gestão de Estoque - Movimentação (Requisito 7)
app.post('/api/movimentacao', (req, res) => {
    const { produto_id, usuario_id, tipo, quantidade, data } = req.body;
    
    // 1. Buscar produto atual
    db.get('SELECT * FROM produtos WHERE id = ?', [produto_id], (err, produto) => {
        if (err || !produto) return res.status(404).json({ error: 'Produto não encontrado' });

        let novaQtd = produto.quantidade;
        let alerta = null;

        // Calcular nova quantidade
        if (tipo === 'entrada') {
            novaQtd += parseInt(quantidade);
        } else if (tipo === 'saida') {
            novaQtd -= parseInt(quantidade);
            if (novaQtd < 0) return res.status(400).json({ error: 'Estoque insuficiente' });
            
            // Requisito 7.1.4: Verificar estoque mínimo na saída
            if (novaQtd < produto.quantidade_minima) {
                alerta = `ATENÇÃO: Estoque do produto ${produto.nome} ficou abaixo do mínimo (${produto.quantidade_minima})!`;
            }
        }

        // 2. Atualizar Produto
        db.run('UPDATE produtos SET quantidade = ? WHERE id = ?', [novaQtd, produto_id], (err) => {
            if (err) return res.status(500).json({ error: err.message });

            // 3. Registrar Histórico (Requisito 5 e 6)
            db.run('INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, data_movimentacao) VALUES (?,?,?,?,?)',
                [produto_id, usuario_id, tipo, quantidade, data], (err) => {
                    if (err) return res.status(500).json({ error: err.message });
                    
                    res.json({ 
                        success: true, 
                        nova_quantidade: novaQtd, 
                        alerta_estoque: alerta // Retorna o alerta para o front-end
                    });
            });
        });
    });
});

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});