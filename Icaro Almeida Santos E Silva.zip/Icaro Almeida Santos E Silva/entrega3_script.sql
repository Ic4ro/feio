-- ENTREGA 3: Script de Criação e População do Banco de Dados
-- Nome do Banco: saep_db

-- 1. Criação da Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha TEXT NOT NULL
);

-- 2. Criação da Tabela de Produtos
CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    preco REAL NOT NULL,
    quantidade INTEGER NOT NULL,
    quantidade_minima INTEGER NOT NULL
);

-- 3. Criação da Tabela de Movimentações (Histórico)
CREATE TABLE IF NOT EXISTS movimentacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    produto_id INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL,
    tipo TEXT NOT NULL, -- 'entrada' ou 'saida'
    quantidade INTEGER NOT NULL,
    data_movimentacao TEXT NOT NULL,
    FOREIGN KEY (produto_id) REFERENCES produtos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- POPULAÇÃO DE DADOS (Mínimo de 3 registros por tabela)

-- Inserindo 3 Usuários
INSERT INTO usuarios (nome, email, senha) VALUES 
('Admin', 'admin@senai.br', '1234'),
('João Silva', 'joao@empresa.com', 'senha123'),
('Maria Oliveira', 'maria@empresa.com', 'senha456');

-- Inserindo 3 Produtos
INSERT INTO produtos (nome, preco, quantidade, quantidade_minima) VALUES 
('Notebook Dell', 3500.00, 10, 2),
('Mouse Logitech', 50.00, 30, 5),
('Teclado Mecânico', 250.00, 15, 3);

-- Inserindo 3 Movimentações de Estoque
-- Obs: IDs referenciam os produtos e usuários criados acima
INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, data_movimentacao) VALUES 
(1, 1, 'entrada', 10, '2023-11-28'),
(2, 2, 'saida', 2, '2023-11-28'),
(3, 3, 'entrada', 5, '2023-11-29');